/*
 * Author:		Chris Trimmer
 * FileName:	ContactTest.java
 * Assignment:	3-2 Milestone
 * Date:		1/17/2023
 * Test Coverage:	100%
 * 
 * The purpose of the ContactTest unit test is to test the
 * following functionality: object creation, and pass/fail of
 * accessor and mutator methods.
 * 
 */

package com.grandstrandsystems.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.grandstrandsystems.contact.Contact;

@DisplayName("All Contact Tests")
class ContactTest {
	
	// variables used for testing
	private Contact contact;
	private String valid10;
	private String valid30;
	private String invalid11;
	private String invalid31;
	private String blank;
	private char[] char10; 
	private char[] char11;
	private char[] char30;
	private char[] char31;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	// initialize variables before each test
	@BeforeEach
	void setUp() throws Exception {
		char10 = new char[10];
		Arrays.fill(char10, 'x');
		valid10 = String.valueOf(char10);
		
		char11 = new char[11];
		Arrays.fill(char11, 'x');
		invalid11 = String.valueOf(char11);
		
		char30 = new char[30];
		Arrays.fill(char30, 'x');
		valid30 = String.valueOf(char30);
		
		char31 = new char[31];
		Arrays.fill(char31, 'x');
		invalid31 = String.valueOf(char31);
		
		blank = "";
		
		contact = new Contact(valid10, valid10, valid10, valid10, valid30);
	}

	// set variables to null after each test
	@AfterEach
	void tearDown() throws Exception {
		char10 = null;
		char11 = null;
		char30 = null;
		char31 = null;
		invalid11 = null;
		invalid31 = null;
		valid10 = null;
		valid30 = null;
		contact = null;
		blank = null;
	}

	// test creation of a contact
	@Test
	@DisplayName("Create Contact")
	void createContact() {
		assertEquals(contact.getContactId(), valid10);
		assertEquals(contact.getContactFirstName(), valid10);
		assertEquals(contact.getContactLastName(), valid10);
		assertEquals(contact.getContactPhone(), valid10);
		assertEquals(contact.getContactAddress(), valid30);
	}
	
	
	// ContactId tests
	@Test
	@DisplayName("contactId is null")
	void contactIdNull() {
		Throwable exception = assertThrows(NullPointerException.class, ()-> {
			contact.setContactId(null);
		});
		
		assertEquals(NullPointerException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("contactId is blank")
	void contactIdBlank() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			contact.setContactId(blank);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("contactId is over 10 chars")
	void contactIdLength() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			contact.setContactId(invalid11);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	// FirstName tests
	@Test
	@DisplayName("firstName is null")
	void firstNameNull() {
		Throwable exception = assertThrows(NullPointerException.class, ()-> {
			contact.setContactFirstName(null);
		});
		
		assertEquals(NullPointerException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("firstName is blank")
	void contactFirstNameBlank() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			contact.setContactFirstName(blank);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("firstName is over 10 chars")
	void firstNameLength() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			contact.setContactFirstName(invalid11);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}

	
	// LastName tests
	@Test
	@DisplayName("lastName is null")
	void lastNameNull() {
		Throwable exception = assertThrows(NullPointerException.class, ()-> {
			contact.setContactLastName(null);
		});
		
		assertEquals(NullPointerException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("contactLastName is blank")
	void contactLastNameBlank() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			contact.setContactLastName(blank);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("lastName is over 10 chars")
	void lastNameLength() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			contact.setContactLastName(invalid11);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	
	// Phone tests
	@Test
	@DisplayName("phone is null")
	void phoneNull() {
		Throwable exception = assertThrows(NullPointerException.class, ()-> {
			contact.setContactPhone(null);
		});
		
		assertEquals(NullPointerException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("contactPhone is blank")
	void contactPhoneBlank() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			contact.setContactPhone(blank);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("phone is over 10 chars")
	void phoneLength() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			contact.setContactPhone(invalid11);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}

	
	// Address tests
	@Test
	@DisplayName("address is null")
	void addressNull() {
		Throwable exception = assertThrows(NullPointerException.class, ()-> {
			contact.setContactAddress(null);
		});
		
		assertEquals(NullPointerException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("contactAddress is blank")
	void contactAddressBlank() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			contact.setContactAddress(blank);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("address is over 30 chars")
	void addressLength() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			contact.setContactAddress(invalid31);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}

	
}
