/*
 * Author:		Chris Trimmer
 * FileName:	AppointmentServiceTest.java
 * Assignment:	5-1 Milestone
 * Date:		1/31/2023
 * Test Coverage:	100%
 * 
 * The purpose of the AppointmentServiceTest unit test is to test 
 * the CRUD operations defined in TaskService class
 * 
 */

package com.grandstrandsystems.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Arrays;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.grandstrandsystems.appointment.Appointment;
import com.grandstrandsystems.appointment.AppointmentService;
import com.grandstrandsystems.task.Task;

@DisplayName("All AppointmentService Tests")
class AppointmentServiceTest {
	
	// variables used in testing
	private AppointmentService as;
	private LocalDate validDate;
	private LocalDate invalidDate;
	private String valid10;
	private String valid50;
	private String blank;
	private String invalid11;
	private String invalid51;
	private char[] char10;
	private char[] char11;
	private char[] char50;
	private char[] char51;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	// initialize variables before each test
	@BeforeEach
	void setUp() throws Exception {
		char10 = new char[10];
		Arrays.fill(char10, 'x');
		valid10 = String.valueOf(char10);
		
		char11 = new char[11];
		Arrays.fill(char11, 'x');
		invalid11 = String.valueOf(char11);
		
		char50 = new char[50];
		Arrays.fill(char50, 'x');
		valid50 = String.valueOf(char50);
		
		char51 = new char[51];
		Arrays.fill(char51, 'x');
		invalid51 = String.valueOf(char51);
		
		blank = "   ";
		validDate = LocalDate.now();
		invalidDate = validDate.minusDays(1);
		
		as = new AppointmentService();
	}

	// set variables to null after each test
	@AfterEach
	void tearDown() throws Exception {
		
		char10 = null;
		char11 = null;
		char50 = null;
		char51 = null;
		invalid11 = null;
		invalid51 = null;
		valid10 = null;
		valid50 = null;
		validDate = null;
		invalidDate = null;
		
		as.appointments.clear();
		as = null;
	}

	// test adding appointment objects to list
	@Test
	@DisplayName("add appointment to ArrayList")
	void addAppointment() {
		Appointment newAppointment = new Appointment(valid10, validDate, valid50);
		Appointment newAppointment1 = new Appointment("1234567890", validDate, valid50);
		
		assertTrue(as.addAppointment(newAppointment1));
		assertTrue(as.addAppointment(newAppointment));
		assertFalse(as.addAppointment(newAppointment1));
	}

	// delete appointment from list
	@Test
	@DisplayName("delete appointment from ArrayList")
	void deleteAppointment() {
		Appointment newAppointment = new Appointment(valid10, validDate, valid50);
		as.addAppointment(newAppointment);
		
		assertFalse(as.deleteAppointment("unknown id"));
		assertTrue(as.deleteAppointment(valid10));
		
	}
	
	// update appointment in list
	@Test
	@DisplayName("update appointment in ArrayList")
	void updateAppointment() {
		Appointment newAppointment = new Appointment(valid10, validDate, valid50);
		as.addAppointment(newAppointment);
		
		assertTrue(as.updateAppointment(valid10, validDate.plusDays(1), "new description"));
		assertFalse(as.updateAppointment("unknown id", validDate, valid50));
	}

}
