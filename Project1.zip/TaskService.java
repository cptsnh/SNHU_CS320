/*
 * Author:		Chris Trimmer
 * FileName:	TaskService.java
 * Assignment:	4-1 Milestone
 * Date:		1/25/2023
 * 
 * The purpose of the TaskService class is to store a list of
 * Tasks in an ArrayList, and to enable basic CRUD operations
 * on the list.
 * 
 */

package com.grandstrandsystems.task;

import java.util.ArrayList;

public class TaskService {
	public ArrayList<Task> tasks;
	
	// Non-parameterized constructor
	public TaskService() {
		tasks = new ArrayList<Task>();
	}
	
	// Add a task
	public boolean addTask(Task task) {
		for(Task t : tasks) {
			if (task.getTaskId().equals(t.getTaskId())) {
				System.err.println("taskId already exists");
				return false;
			}
		}
		
		tasks.add(task);
		return true;
	}
	
	// Delete a task
	public boolean deleteTask(String taskId) {
		for (Task t : tasks) {
			if (taskId.equals(t.getTaskId())) {
				tasks.remove(t);
				return true;
			}
		}
		
		return false;
	}
	
	// Update a task
	public boolean updateTask(String taskId, String taskName, String taskDesc) {
		for (Task t : tasks) {
			if (taskId.equals(t.getTaskId())) {
				t.setTaskName(taskName);
				t.setTaskDescription(taskDesc);
				return true;
			}
		}
		
		return false;
	}
}
