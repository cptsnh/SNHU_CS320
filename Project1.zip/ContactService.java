/*
 * Author:		Chris Trimmer
 * FileName:	ContactService.java
 * Assignment:	3-2 Milestone
 * Date:		1/17/2023
 * 
 * The purpose of the ContactService class is to store a list of
 * Contacts in an ArrayList, and to enable basic CRUD operations
 * on the list.
 * 
 */

package com.grandstrandsystems.contact;

import java.util.ArrayList;

public class ContactService {

	public ArrayList<Contact> contacts;
	
	// Non-parameterized constructor
	public ContactService() {
		contacts = new ArrayList<Contact>();
		
	}
	
	// Function to add a contact
	public boolean addContact(Contact contact) {
		for (Contact c : contacts) {
			if (contact.getContactId().equals(c.getContactId())) {
				System.err.println("contactId already exists");
				return false;
			}
		}
		
		contacts.add(contact);
		return true;
	}
	
	/*
	 *  Function to delete a contact
	 */
	public boolean deleteContact(String contactId) {
		for (Contact c : contacts) {
			if (c.getContactId().equals(contactId)) {
				contacts.remove(c);
				return true;
			}
		}
		
		return false;
	}
	
	/*
	 *  Function to update a contact
	 *  ContactID is not modifiable
	 */
	public boolean updateContact(String contactId, String fName, String lName,
			String phone, String address) {
		
		for (Contact c : contacts) {
			if (c.getContactId().equals(contactId)) {
				c.setContactFirstName(fName);
				c.setContactLastName(lName);
				c.setContactPhone(phone);
				c.setContactAddress(address);
				return true;
			}
		}
		
		return false;
		
	}
	
	
	
}
