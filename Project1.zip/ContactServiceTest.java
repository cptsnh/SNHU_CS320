/*
 * Author:		Chris Trimmer
 * FileName:	ContactServiceTest.java
 * Assignment:	3-2 Milestone
 * Date:		1/17/2023
 * Test Coverage:	100%
 * 
 * The purpose of the ContactServiceTest unit test is to test 
 * the CRUD operations defined in ContactService class
 * 
 */

package com.grandstrandsystems.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;

import org.junit.jupiter.api.Test;

import com.grandstrandsystems.contact.Contact;
import com.grandstrandsystems.contact.ContactService;

@DisplayName("All ContactService tests")
class ContactServiceTest {

	// variables used in this test
	private ContactService cs;
	private String valid10;
	private String valid30;
	private char[] char10;
	private char[] char30;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	// initialize variables before each test
	@BeforeEach
	void setUp() throws Exception {
		
		cs = new ContactService();
		char10 = new char[10];
		Arrays.fill(char10, 'x');
		valid10 = String.valueOf(char10);
		
		char30 = new char[30];
		Arrays.fill(char30, 'x');
		valid30 = String.valueOf(char30);		
	}

	// set variables to null after each test
	@AfterEach
	void tearDown() throws Exception {
		char10 = null;
		char30 = null;
		valid10 = null;
		valid30 = null;
		cs.contacts.clear();
		cs = null;
	}

	// Test creation of contact list and adding contacts
	@Test
	@DisplayName("add contact to contacts list")
	void addContact() {
		Contact newContact = new Contact(valid10, valid10, valid10, valid10, valid30);
		Contact newContact1 = new Contact("1234567890", valid10, valid10, valid10, valid30);
		assertTrue(cs.addContact(newContact1));
		assertTrue(cs.addContact(newContact));
		assertFalse(cs.addContact(newContact1));
		
	}

	// Test deletion of a contact
	@Test
	@DisplayName("delete contact from contacts list")
	void deleteContact() {
		Contact newContact = new Contact(valid10, valid10, valid10, valid10, valid30);
		cs.addContact(newContact);
		
		assertFalse(cs.deleteContact("100"));
		assertTrue(cs.deleteContact(newContact.getContactId()));
	}
	
	// Test update of a contact
	@Test
	@DisplayName("update contact in contacts list")
	void updateContact() {
		Contact newContact = new Contact(valid10, valid10, valid10, valid10, valid30);
		cs.addContact(newContact);
		
		assertTrue(cs.updateContact(newContact.getContactId(), "New First", "New Last",
				"1234567890", "New Address"));
		assertFalse(cs.updateContact("unknown id", "New First", "New Last", "1234567890", "New Address"));
		
	}
}
