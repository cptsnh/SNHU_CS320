/*
 * Author:		Chris Trimmer
 * FileName:	AppointmentTest.java
 * Assignment:	5-1 Milestone
 * Date:		1/31/2023
 * Test Coverage:	100%
 * 
 * The purpose of the AppointmentTest unit test is to test the
 * following functionality: object creation, and pass/fail of
 * accessor and mutator methods.
 * 
 */

package com.grandstrandsystems.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import java.util.Arrays;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.grandstrandsystems.appointment.Appointment;
import com.grandstrandsystems.contact.Contact;
import com.grandstrandsystems.task.Task;

@DisplayName("All Appointment Tests")
class AppointmentTest {

	// variables used in testing
	private Appointment appointment;
	private LocalDate validDate;
	private LocalDate invalidDate;
	private String valid10;
	private String valid50;
	private String blank;
	private String invalid11;
	private String invalid51;
	private char[] char10;
	private char[] char11;
	private char[] char50;
	private char[] char51;
	
	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	// initialize variables before each test
	@BeforeEach
	void setUp() throws Exception {
		
		char10 = new char[10];
		Arrays.fill(char10, 'x');
		valid10 = String.valueOf(char10);
		
		char11 = new char[11];
		Arrays.fill(char11, 'x');
		invalid11 = String.valueOf(char11);
		
		char50 = new char[50];
		Arrays.fill(char50, 'x');
		valid50 = String.valueOf(char50);
		
		char51 = new char[51];
		Arrays.fill(char51, 'x');
		invalid51 = String.valueOf(char51);
		
		blank = "   ";
		validDate = LocalDate.now();
		invalidDate = validDate.minusDays(1);
		
		appointment = new Appointment(valid10, validDate, valid50);
	}

	// set variables to null after each test
	@AfterEach
	void tearDown() throws Exception {
		char10 = null;
		char11 = null;
		char50 = null;
		char51 = null;
		invalid11 = null;
		invalid51 = null;
		valid10 = null;
		valid50 = null;
		validDate = null;
		invalidDate = null;
		appointment = null;
	}

	//  test creation of Appointments
	@Test
	@DisplayName("create new appointment")
	void createAppointment() {
		assertEquals(appointment.getAppointmentId(), valid10);
		assertEquals(appointment.getAppointmentDate(), validDate);
		assertEquals(appointment.getAppointmentDescription(), valid50);
	}
	
	// Id tests
	@Test
	@DisplayName("appointmentId is null")
	void appointmentIdNull() {
		Throwable exception = assertThrows(NullPointerException.class, ()-> {
			appointment.setAppointmentId(null);
		});
		
		assertEquals(NullPointerException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("appointmentId is blank")
	void appoinmentIdBlank() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			appointment.setAppointmentId(blank);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("appointmentId is over 10 chars")
	void appoinmentIdLength() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			appointment.setAppointmentId(invalid11);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	
	// Date tests
	@Test
	@DisplayName("appointmentDate is null")
	void appointmentDateNull() {
		Throwable exception = assertThrows(NullPointerException.class, ()-> {
			appointment.setAppointmentDate(null);
		});
		
		assertEquals(NullPointerException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("appointmentDate is invalid")
	void appointmentIdInvalid() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			appointment.setAppointmentDate(invalidDate);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	// Description tests
	@Test
	@DisplayName("appointmentDescription is null")
	void appointmentDescriptionNull() {
		Throwable exception = assertThrows(NullPointerException.class, ()-> {
			appointment.setAppointmentDescription(null);
		});
		
		assertEquals(NullPointerException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("appointmentDescription is blank")
	void appoinmentDescriptionBlank() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			appointment.setAppointmentDescription(blank);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("appointmentDescription is over 50 chars")
	void appoinmentDescriptionLength() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			appointment.setAppointmentDescription(invalid51);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	
	

}
