/*
 * Author:		Chris Trimmer
 * FileName:	AppointmentService.java
 * Assignment:	5-1 Milestone
 * Date:		1/31/2023
 * 
 * The purpose of the AppointmentService class is to store a list of
 * Appointment in an ArrayList, and to enable basic CRUD operations
 * on the list.
 * 
 */

package com.grandstrandsystems.appointment;

import java.time.LocalDate;
import java.util.ArrayList;

public class AppointmentService {
	
	public ArrayList<Appointment> appointments;
	
	// Non-parameterized constructor
	public AppointmentService() {
		appointments = new ArrayList<Appointment>();
	}
	
	// add an appointment
	public boolean addAppointment(Appointment appt) {
		for (Appointment a : appointments) {
			if (appt.getAppointmentId().equals(a.getAppointmentId())) {
				System.err.println("appointmentId already exists");
				return false;
			}
		}
		
		appointments.add(appt);
		return true;
	}
	
	// delete an appointment
	public boolean deleteAppointment(String id) {
		for (Appointment a : appointments) {
			if (id.equals(a.getAppointmentId())) {
				appointments.remove(a);
				return true;				
			}
		}
		
		return false;
	}
	
	// update an appointment
	public boolean updateAppointment(String id, LocalDate date, String desc) {
		for (Appointment a : appointments) {
			if (id.equals(a.getAppointmentId())) {
				a.setAppointmentDate(date);
				a.setAppointmentDescription(desc);
				return true;				
			}
		}
		
		return false;
	}
	
}
