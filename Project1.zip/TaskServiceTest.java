/*
 * Author:		Chris Trimmer
 * FileName:	TaskServiceTest.java
 * Assignment:	4-1 Milestone
 * Date:		1/25/2023
 * Test Coverage:	100%
 * 
 * The purpose of the TaskServiceTest unit test is to test 
 * the CRUD operations defined in TaskService class
 * 
 */

package com.grandstrandsystems.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.grandstrandsystems.task.Task;
import com.grandstrandsystems.task.TaskService;

@DisplayName("All TaskService Tests")
class TaskServiceTest {

	// variables used in testing
	TaskService ts;
	private String valid10;
	private String valid20;
	private String valid50;
	private char[] char10;
	private char[] char20;
	private char[] char50;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	// initialize variables before each test
	@BeforeEach
	void setUp() throws Exception {
		
		char10 = new char[10];
		Arrays.fill(char10, 'x');
		valid10 = String.valueOf(char10);
		
		char20 = new char[20];
		Arrays.fill(char20, 'x');
		valid20 = String.valueOf(char20);
		
		char50 = new char[50];
		Arrays.fill(char50, 'x');
		valid50 = String.valueOf(char50);
		
		ts = new TaskService();
	}

	// set variables to null after each test
	@AfterEach
	void tearDown() throws Exception {
		char10 = null;
		char20 = null;
		char50 = null;
		valid10 = null;
		valid20 = null;
		valid50 = null;
		ts.tasks.clear();
		ts = null;
	}

	// Test adding tasks to list
	@Test
	@DisplayName("add task to ArrayList")
	void addTask() {
		Task newTask = new Task(valid10, valid20, valid50);
		Task newTask1 = new Task("1234567890", valid20, valid50);
		
		assertTrue(ts.addTask(newTask1));
		assertTrue(ts.addTask(newTask));
		assertFalse(ts.addTask(newTask1));
	}

	// Test task deletion
	@Test
	@DisplayName("delete task from ArrayList")
	void deleteTask() {
		Task newTask = new Task(valid10, valid20, valid50);
		ts.addTask(newTask);
		
		assertFalse(ts.deleteTask("unknown id"));
		assertTrue(ts.deleteTask(valid10));
		
	}
	
	// Test updates to a task
	@Test
	@DisplayName("update task in ArrayList")
	void updateTask() {
		Task newTask = new Task(valid10, valid20, valid50);
		ts.addTask(newTask);
		
		assertTrue(ts.updateTask(valid10, "new name", "new description"));
		assertFalse(ts.updateTask("unknown id", valid20, valid50));
	}
	
}
