/*
 * Author:		Chris Trimmer
 * FileName:	Contact.java
 * Assignment:	3-2 Milestone
 * Date:		1/17/2023
 * 
 * The purpose of the Contact class is to define member variables 
 * and methods that define a Contact object. The class consists
 * of a parameterized constructor and five data members along with
 * their respective accessor and mutator methods.
 * 
 */

package com.grandstrandsystems.contact;

public class Contact {

	// Member variables
	private String contactId;
	private String contactFirstName;
	private String contactLastName;
	private String contactPhone;
	private String contactAddress;
	
	// Initialization block
	{
		contactId = "0";
		contactFirstName = "default first name";
		contactLastName = "default last name";
		contactPhone = "default phone";
		contactAddress = "default address";
	}
	
	// Parameterized constructor
	public Contact(String id, String firstName, String lastName, String phone, String address) {
		
		// use mutator methods to set the member variables upon object creation
		setContactId(id);
		setContactFirstName(firstName);
		setContactLastName(lastName);
		setContactPhone(phone);
		setContactAddress(address);
	}

	/**
	 * @return the contactId
	 */
	public String getContactId() {
		return contactId;
	}

	/**
	 * @param contactId the contactId to set
	 */
	public void setContactId(String contactId) {

		if (contactId == null)
			throw new NullPointerException("contactId is null");
		
		if (contactId.trim().isBlank())
			throw new IllegalArgumentException("contactId is invalid");
		
		if (contactId.length() > 10)
			throw new IllegalArgumentException("contactId is over 10 chars");
		
		this.contactId = contactId;
	}

	/**
	 * @return the contactFirstName
	 */
	public String getContactFirstName() {
		return contactFirstName;
	}

	/**
	 * @param contactFirstName the contactFirstName to set
	 */
	public void setContactFirstName(String firstName) {

		if (firstName == null)
			throw new NullPointerException("contactFirstName is null");

		if (firstName.trim().isBlank())
			throw new IllegalArgumentException("contactFirstName is invalid");
		
		if (firstName.length() > 10)
			throw new IllegalArgumentException("contactFirstName is over 10 chars");

		this.contactFirstName = firstName;
	}

	/**
	 * @return the contactLastName
	 */
	public String getContactLastName() {
		return contactLastName;
	}

	/**
	 * @param contactLastName the contactLastName to set
	 */
	public void setContactLastName(String contactLastName) {
		
		if (contactLastName == null)
			throw new NullPointerException("contactLastName is null");

		if (contactLastName.trim().isBlank())
			throw new IllegalArgumentException("contactLastName is invalid");
		
		if (contactLastName.length() > 10)
			throw new IllegalArgumentException("contactLastName is over 10 chars");

		this.contactLastName = contactLastName;
	}

	/**
	 * @return the contactPhone
	 */
	public String getContactPhone() {
		return contactPhone;
	}

	/**
	 * @param contactPhone the contactPhone to set
	 */
	public void setContactPhone(String contactPhone) {
		
		if (contactPhone == null)
			throw new NullPointerException("contactId is null");

		if (contactPhone.trim().isBlank())
			throw new IllegalArgumentException("contactPhone is invalid");

		if (contactPhone.length() != 10)
			throw new IllegalArgumentException("contactPhone is not 10 chars");
		
		this.contactPhone = contactPhone;
	}

	/**
	 * @return the contactAddress
	 */
	public String getContactAddress() {
		return contactAddress;
	}

	/**
	 * @param contactAddress the contactAddress to set
	 */
	public void setContactAddress(String contactAddress) {
		
		if (contactAddress == null)
			throw new NullPointerException("contactAddress is null");
		
		if (contactAddress.trim().isBlank())
			throw new IllegalArgumentException("contactAddress is invalid");

		if (contactAddress.length() > 30)
			throw new IllegalArgumentException("contactAddress is over 30 chars");
		
		this.contactAddress = contactAddress;
	}
	
	
	
	
	
}
