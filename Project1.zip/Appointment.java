/*
 * Author:		Chris Trimmer
 * FileName:	Appointment.java
 * Assignment:	5-1 Milestone
 * Date:		1/31/2023
 * 
 * The purpose of the Appointment class is to define member variables 
 * and methods that define an Appointment object. The class consists
 * of a parameterized constructor and three data members along with
 * their respective accessor and mutator methods.
 * 
 */

package com.grandstrandsystems.appointment;

import java.time.LocalDate;

public class Appointment {

	// member variables
	private String appointmentId;
	private LocalDate appointmentDate;
	private String appointmentDescription;
	
	// initialization block
	{
		appointmentId = "0";
		appointmentDate = LocalDate.now();
		appointmentDescription = "appointment description";
	}
	
	// parameterized constructor
	public Appointment(String id, LocalDate date, String description) {
		setAppointmentId(id);
		setAppointmentDate(date);
		setAppointmentDescription(description);
	}

	/**
	 * @return the appointmentId
	 */
	public String getAppointmentId() {
		return appointmentId;
	}

	/**
	 * @param appointmentId the appointmentId to set
	 */
	public void setAppointmentId(String appointmentId) {
		
		if (appointmentId == null)
			throw new NullPointerException("appointmentId is null");
		
		if (appointmentId.trim().isBlank())
			throw new IllegalArgumentException("appointmentId is invalid");
		
		if (appointmentId.length() > 10)
			throw new IllegalArgumentException("appointmentId is over 10 chars");
		
		this.appointmentId = appointmentId;
	}

	/**
	 * @return the appointmentDate
	 */
	public LocalDate getAppointmentDate() {
		return appointmentDate;
	}

	/**
	 * @param appointmentDate the appointmentDate to set
	 */
	public void setAppointmentDate(LocalDate appointmentDate) {
		
		if (appointmentDate == null)
			throw new NullPointerException("appointmentId is null");
		
		if (appointmentDate.isBefore(LocalDate.now()))
			throw new IllegalArgumentException("appointmentDate is invalid");
		
		this.appointmentDate = appointmentDate;
	}

	/**
	 * @return the appointmentDescription
	 */
	public String getAppointmentDescription() {
		return appointmentDescription;
	}

	/**
	 * @param appointmentDescription the appointmentDescription to set
	 */
	public void setAppointmentDescription(String appointmentDescription) {
		
		if (appointmentDescription == null)
			throw new NullPointerException("appointmentDescription is null");
		
		if (appointmentDescription.trim().isBlank())
			throw new IllegalArgumentException("appointmentDescription is invalid");
		
		if (appointmentDescription.length() > 50)
			throw new IllegalArgumentException("appointmentDescription is over 50 chars");
		
		this.appointmentDescription = appointmentDescription;
	}
	
	
	
}
