/*
 * Author:		Chris Trimmer
 * FileName:	TaskTest.java
 * Assignment:	4-1 Milestone
 * Date:		1/25/2023
 * Test Coverage:	100%
 * 
 * The purpose of the TaskTest unit test is to test the
 * following functionality: object creation, and pass/fail of
 * accessor and mutator methods.
 * 
 */

package com.grandstrandsystems.testing;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Arrays;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import com.grandstrandsystems.task.Task;

@DisplayName("All Task Tests")
class TaskTest {
	
	// variables used in testing
	private Task task;
	private String valid10;
	private String valid20;
	private String valid50;
	private String blank;
	private String invalid11;
	private String invalid21;
	private String invalid51;
	private char[] char10;
	private char[] char11;
	private char[] char20;
	private char[] char21;
	private char[] char50;
	private char[] char51;


	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	// initialize variables before each test
	@BeforeEach
	void setUp() throws Exception {
		
		char10 = new char[10];
		Arrays.fill(char10, 'x');
		valid10 = String.valueOf(char10);
		
		char11 = new char[11];
		Arrays.fill(char11, 'x');
		invalid11 = String.valueOf(char11);
		
		char20 = new char[20];
		Arrays.fill(char20, 'x');
		valid20 = String.valueOf(char20);
		
		char21 = new char[21];
		Arrays.fill(char21, 'x');
		invalid21 = String.valueOf(char21);
		
		char50 = new char[50];
		Arrays.fill(char50, 'x');
		valid50 = String.valueOf(char50);
		
		char51 = new char[51];
		Arrays.fill(char51, 'x');
		invalid51 = String.valueOf(char51);
		
		blank = "  ";
		
		task = new Task(valid10, valid20, valid50);
		
	}

	// set variables to null after each test
	@AfterEach
	void tearDown() throws Exception {
		char10 = null;
		char11 = null;
		char20 = null;
		char21 = null;
		char50 = null;
		char51 = null;
		invalid11 = null;
		invalid21 = null;
		invalid51 = null;
		valid10 = null;
		valid20 = null;
		valid50 = null;
		task = null;
	}

	// Test creation of tasks
	@Test
	void createTask() {
		assertEquals(task.getTaskId(), valid10);
		assertEquals(task.getTaskName(), valid20);
		assertEquals(task.getTaskDescription(), valid50);
	}
	
	// TaskId tests
	@Test
	@DisplayName("taskId is null")
	void taskIdNull() {
		Throwable exception = assertThrows(NullPointerException.class, ()-> {
			task.setTaskId(null);
		});
		
		assertEquals(NullPointerException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("taskId is blank")
	void taskIdBlank() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			task.setTaskId(blank);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
		
	@Test
	@DisplayName("taskId is over 10 chars")
	void taskIdLength() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			task.setTaskId(invalid11);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	// TaskName tests
	@Test
	@DisplayName("taskName is null")
	void taskNameNull() {
		Throwable exception = assertThrows(NullPointerException.class, ()-> {
			task.setTaskName(null);
		});
		
		assertEquals(NullPointerException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("taskName is blank")
	void taskNameBlank() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			task.setTaskName(blank);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("taskName is over 20 chars")
	void taskNameLength() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			task.setTaskName(invalid21);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	
	// taskDescription tests
	@Test
	@DisplayName("taskDescription is null")
	void taskDescriptionNull() {
		Throwable exception = assertThrows(NullPointerException.class, ()-> {
			task.setTaskDescription(null);
		});
		
		assertEquals(NullPointerException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("taskDescription is blank")
	void taskDescriptionBlank() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			task.setTaskDescription(blank);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	
	@Test
	@DisplayName("taskDescription is over 50 chars")
	void taskDescriptionLength() {
		Throwable exception = assertThrows(IllegalArgumentException.class, ()-> {
			task.setTaskDescription(invalid51);
		});
		
		assertEquals(IllegalArgumentException.class, exception.getClass());
	}
	

}
