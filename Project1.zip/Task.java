/*
 * Author:		Chris Trimmer
 * FileName:	Task.java
 * Assignment:	4-1 Milestone
 * Date:		1/25/2023
 * 
 * The purpose of the Task class is to define member variables 
 * and methods that define a Task object. The class consists
 * of a parameterized constructor and three data members along with
 * their respective accessor and mutator methods.
 * 
 */

package com.grandstrandsystems.task;

public class Task {

	private String taskId;
	private String taskName;
	private String taskDescription;
	
	// Initialization block
	{
		taskId = "0";
		taskName = "default task name";
		taskDescription = "task description";
	}
	
	// Parameterized constructor
	public Task(String id, String name, String desc) {
		setTaskId(id);
		setTaskName(name);
		setTaskDescription(desc);
	} 
	
	/**
	 * @return the taskId
	 */
	public String getTaskId() {
		return taskId;
	}

	/**
	 * @param taskId the taskId to set
	 */
	public void setTaskId(String taskId) {
		
		if (taskId == null)
			throw new NullPointerException("taskId is null");
		
		if (taskId.trim().isBlank())
			throw new IllegalArgumentException("taskId is invalid");
		
		if (taskId.length() > 10)
			throw new IllegalArgumentException("taskId is longer than 10 chars");
		
		this.taskId = taskId;
	}

	/**
	 * @return the taskName
	 */
	public String getTaskName() {
		return taskName;
	}

	/**
	 * @param taskName the taskName to set
	 */
	public void setTaskName(String taskName) {

		if (taskName == null)
			throw new NullPointerException("taskId is null");
		
		if (taskName.trim().isBlank())
			throw new IllegalArgumentException("taskName is invalid");
		
		if (taskName.length() > 20)
			throw new IllegalArgumentException("taskId is longer than 20 chars");
		
		this.taskName = taskName;
	}

	/**
	 * @return the taskDescription
	 */
	public String getTaskDescription() {
		return taskDescription;
	}

	/**
	 * @param taskDescription the taskDescription to set
	 */
	public void setTaskDescription(String taskDescription) {
		
		if (taskDescription == null)
			throw new NullPointerException("taskDescription is null");
		
		if (taskDescription.trim().isBlank())
			throw new IllegalArgumentException("taskDescription is invalid");
		
		if (taskDescription.length() > 50)
			throw new IllegalArgumentException("taskDescription is longer than 50 chars");
		
		this.taskDescription = taskDescription;
	}
	
	
	
}
